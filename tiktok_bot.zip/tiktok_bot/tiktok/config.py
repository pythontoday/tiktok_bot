vk_phone = "your_phone"
vk_password = "your_password"
